import pickle
import random

########################################################################################
#             This script is used for selection of features in a random way.
#             The first 32 features are of APIs, next 4 are of Assembly and
#             the last 3 are of some properties of PE and its associated label
#             Date : 28-6-2020
#             version : 28-6.v2
########################################################################################







################################ MAIN_START ########################################################

# Loading the ransomware's API into memory
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/countedApiRansom.dict","rb") as my_dataset_read:
    r_API=pickle.load(my_dataset_read)
    my_dataset_read.close()

# Saving the APIs into a list
selected_features=[]
i=1
for each in r_API:
    if each!=' ':
        selected_features.append(each)
    else:
        i-=1
    if i==100:
        break
    i+=1
    
# Loading the benign's API into memory
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/countedApiBenign.dict","rb") as my_dataset_read:
    b_API=pickle.load(my_dataset_read)
    my_dataset_read.close()

# Saving the APIs into the previous list
i=1
for each in b_API:
    selected_features.append(each)
    if i==100:
        break
    i+=1
        
    
    
# loading the assembly instructions and saving to a list    
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/countedAsmRansom.dict","rb") as my_dataset_read:
    just_ASM=pickle.load(my_dataset_read)
    my_dataset_read.close()


# Saving the top 20 assembly into the previous list
i=1
asm=[]
for each in just_ASM:
    asm.append(each)
    if i==20:
        break
    i+=1
    
# loading the assembly instructions and saving to a list    
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/countedAsmBenign.dict","rb") as my_dataset_read:
    just_b_ASM=pickle.load(my_dataset_read)
    my_dataset_read.close()


# Saving the top 20 assembly into the previous list
i=1

for each in just_b_ASM:
    asm.append(each)
    if i==20:
        break
    i+=1
    





# Saving the list to disk
with open("FrequentlyUsedAPI.list","wb") as write_to_disk:
    pickle.dump(selected_features,write_to_disk)
    write_to_disk.close()

with open("FrequentlyUsedASM.list","wb") as write_to_disk:
    pickle.dump(asm,write_to_disk)
    write_to_disk.close()

#####################################  MAIN END  ###################################################