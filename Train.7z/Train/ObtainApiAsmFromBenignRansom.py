# this one fetches APIs and assembly of exe files and saves the output to disk
import pefile
import glob
import pickle
from collections import Counter
from capstone import *
import operator

def obtain(fileNameOne,fileNameTwo):
    global file_list
    all_APIs=[]
    all_ASM=[]
    for eachFile in file_list:
        try:
            section_number=-1
            pe=pefile.PE(eachFile)
            for entry in pe.DIRECTORY_ENTRY_IMPORT:   # This loop finds the .dll from a malware
                for func in entry.imports:
                    if func.name is not None:
                        all_APIs.append(func.name.decode('utf-8'))
        
            entryPoint=pe.OPTIONAL_HEADER.AddressOfEntryPoint
            for eachSection in pe.sections:
                section_number+=1
                if eachSection.contains_rva(entryPoint):
                    break
            rawSize=pe.sections[section_number].SizeOfRawData
            data = pe.get_memory_mapped_image()[entryPoint:entryPoint+rawSize]
            md = Cs(CS_ARCH_X86, CS_MODE_32)
            for i in md.disasm(data, entryPoint):
                all_ASM.append(i.mnemonic)
            pe=None
        except Exception as e:
            print(e, eachFile)

# computing number of each unique APIs and ASMs        
    counted_API=Counter(all_APIs)
    counted_ASM=Counter(all_ASM)
# sorting the previous result in descending order
    descending_counted_API=dict(sorted(counted_API.items(), key=operator.itemgetter(1),reverse=True))
    descending_counted_ASM=dict(sorted(counted_ASM.items(), key=operator.itemgetter(1),reverse=True))
# saving the descending results to disk
    with open(fileNameOne,"wb") as counted_API_file_handle:
        pickle.dump(descending_counted_API, counted_API_file_handle)
    counted_API_file_handle.close()

    with open(fileNameTwo,"wb") as counted_file_handle:
        pickle.dump(descending_counted_ASM, counted_file_handle)
    counted_file_handle.close()

    return None



##################### MAIN ########################
file_list=[]

# following holds the benign files
file_list+=glob.glob("D:/softwares/exefiles/Benign/*.exe")
s=obtain("countedApiBenign.dict","countedAsmBenign.dict")
file_list.clear()

# following holds the ransomware files
file_list+=glob.glob("D:/softwares/exefiles/Ransom/*.exe")
s=obtain("countedApiRansom.dict","countedAsmRansom.dict")
###########################