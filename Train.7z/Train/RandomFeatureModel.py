import random
import pickle
import numpy 
import pandas
#import sys
from copy import deepcopy
from collections import OrderedDict

########################################################################################
#             This script is used for selection of features in a random way.
#             The first 32 features are of APIs, next 4 are of Assembly and
#             the last 3 are of some properties of PE and its associated label
#             and will train Random Forest
#             date : 2-7-2020
#             version : 2-7-v2
########################################################################################




########################################################################################
# following function randomly selects APIs or Assembly instruction depending on the call
def select_randomly(number_of_selection,my_list):
    global selected_features
    list_length=len(my_list)-1
    i=0
    while i<number_of_selection:
        n=random.randint(0,list_length)
        selected_features.append(my_list[n])
        i+=1
    return None
########################################################################################




################################ MAIN_START ########################################################


# Following parameters are used for system configuration
how_many_api=20
how_many_asm=10
scale_value=500*1048576
size_of_test_data=0.20





#  Reading the lists named "FrequentlyUsedAPI.list", "FrequentlyUsedASM.list", "EndFeature.list" which
#  was written by "RandomFeatureSelection.py" & "FetchData.py"

with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/FrequentlyUsedAPI.list","rb") as read_file:
    frequently_used_api=pickle.load(read_file)
    read_file.close()
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/FrequentlyUsedASM.list","rb") as read_file:
    frequently_used_asm=pickle.load(read_file)
    read_file.close()
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/EndFeature.list","rb") as read_file:
    end_feature=pickle.load(read_file)
    read_file.close()
    

# following list will store the features (randomly select total of 32 APIs & 4 assembly instructions)
selected_features=[]


# following function will randomly select features
select_randomly(how_many_api,frequently_used_api[:40])
select_randomly(how_many_api,frequently_used_api[100:140])

temp=deepcopy(list(OrderedDict.fromkeys(selected_features)))
selected_features.clear()
selected_features=deepcopy(temp)
temp.clear()
asm_start_index=len(selected_features)

select_randomly(how_many_asm,frequently_used_asm[:12])
select_randomly(how_many_asm,frequently_used_asm[20:32])
temp=deepcopy(list(OrderedDict.fromkeys(selected_features)))
selected_features.clear()
selected_features=deepcopy(temp)
temp.clear()
asm_end_index=asm_start_index + (len(selected_features[asm_start_index:]))
selected_features+=end_feature
#print(selected_features)


# Loading the dataset into memory
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/ALLdataset","rb") as my_dataset_read:
    data_set=pickle.load(my_dataset_read)
    my_dataset_read.close()

data=data_set[selected_features]
data=data.loc[:,~data.columns.duplicated()]

print("Features are :")
print(selected_features)
print("\n")


# Scaling the frequency of each instruction
row=len(data["size"])
i=0
j=asm_start_index
column=asm_end_index
#sys.exit()
while j <column:
    i=0
    while i< row:
        scaled=0
        has=data.iloc[i,j]
        size=data.loc[i,"size"]
        scaled=int((has/size)*scale_value)
        #data.iat[i,j]=deepcopy(scaled)
        data.iat[i,j]=deepcopy(scaled)
        #print(scaled)
        i+=1
    j+=1
with open("current_dataset.df","wb") as dfWrite:
    pickle.dump(data,dfWrite)
    dfWrite.close()