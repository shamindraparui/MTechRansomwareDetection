import pandas
import pefile
import glob
import pickle
from capstone import *
from copy import deepcopy
from pefile import PEFormatError
import winsound


###############################################################################################
#      this script is used for fetching all the features at once
#      it will fetch all the 200 APIs and 20 Assembly instructions from all the R/B file
#      Date - 28-6-2020
#      version - 3-7-2020.v1
###############################################################################################


######################## START ###########################################################
def is_valid_EP(my_file, ep, file_path):
    global  section_number
    global total_api
    section_number=-1
    total_api=0
    f=0
    
    for sec in my_file.sections:
        section_number+=1
        if sec.contains_rva(ep):
            f=1
            break
    if f==1:
        if my_file.sections[section_number].Name in [b".aspack\x00", b".adata\x00\x00", b".pec\x00\x00\x00\x00", b"UPX1\x00\x00\x00\x00",
                        b"UPX0\x00\x00\x00\x00",b".MaskPE\x00",b"RCryptor",b".UPX1\x00\x00\x00",
                        b".UPX0\x00\x00\x00", b".yP\x00\x00\x00\x00\x00"]:
            f=2
    try:
        for eachDLL in my_file.DIRECTORY_ENTRY_IMPORT:
            total_api+=len(eachDLL.imports)
    except Exception as e:
        f=(-99)
    return f
############################# END #####################################################





############################### Function starts ########################################
def myfunc():
    global processed_files
    global lbl
    global data_set
    global file_list
    current_file=[]
    all_APIs=[]
    all_ASM=[]
    
    for eachFile in file_list:
        all_APIs.clear()
        all_ASM.clear()
        current_file.clear()
    
        # following try block tries to determine whether a file is valid or packed or corrupted.
        # if file is valid, then only proceed to fetch the info. otherwise continues with the next file from the list.
        try:
            pe=pefile.PE(eachFile)
            entryPoint=pe.OPTIONAL_HEADER.AddressOfEntryPoint
            check_valid=is_valid_EP(pe, entryPoint, eachFile)
            if total_api < 2:
                #print(".net Framework file.\t", eachFile)
                continue
            elif check_valid == 2:
                #print("Packed.\t", eachFile)
                continue
            elif total_api <= 20:
                #print("Possibly Packed by a packer or .Net file.\t", eachFile)
                continue
            elif check_valid == 0:
                #print("Invalid EP. \t", eachFile)
                continue
            elif check_valid == -99:
                #print("No Import Directory.\t", eachFile)
                continue
        except Exception as p:
            #print("From check valid.\t", eachFile)
            continue
        
        
        
        # following try block tries to fetch all the imported API names from the given file. If the file does not contain any
        # API or malformed, then coninues with the next file from the list.
        try:
            for imported_dll in pe.DIRECTORY_ENTRY_IMPORT:   
                for func in imported_dll.imports:            
                    if func.name is not None:
                        all_APIs.append(func.name.decode('utf-8'))
            
            
            # Following loop checks the existence of APIs with the data_set features corresponding to APIs
            # If an API of the current file exists in the data_frame features, then entry "current_file" for this file will
            # contain 1. Otherwise 0. Dataframe contains features corresponding to 200 APIs.
            iteration=0
            api_list_length=len(frequently_used_api)
            while iteration<api_list_length:
                if frequently_used_api[iteration] in all_APIs:
                    current_file.append(1)
                else:
                    current_file.append(0)
                iteration+=1
        except Exception as p:
            print("From API. ",p, eachFile)
            continue

        # Following try block reads the assembly. If any error occurs, continues with the
        # next file from the list.
        
        try:
            rawSize=pe.sections[section_number].SizeOfRawData
            data = pe.get_memory_mapped_image()[entryPoint:entryPoint+rawSize]
            md = Cs(CS_ARCH_X86, CS_MODE_32)
            for i in md.disasm(data, entryPoint):
                if i.mnemonic in frequently_used_asm:
                    all_ASM.append(i.mnemonic)

            # Following loop checks the existence of assembly instruction with the frequently used set
            iteration=0
            asm_list_length=len(frequently_used_asm)
            while iteration < asm_list_length:
                if frequently_used_asm[iteration] in all_ASM:
                    occured=all_ASM.count(frequently_used_asm[iteration])
                    current_file.append(deepcopy(occured))
                else:
                    current_file.append(0)
                iteration+=1

        except Exception as p:
            print("From ASM. ",p, eachFile)
            continue
        try:
            current_file.append(pe.sections[section_number].Characteristics)
            current_file.append(pe.FILE_HEADER.Characteristics)
            current_file.append(pe.sections[section_number].SizeOfRawData)
            current_file.append(pe.sections[section_number].get_entropy())
            pe.close()
        except Exception as p:
            print("From Section characteristics.\t", eachFile)
            continue
            
    

        # Adding label of the code section and the label
        current_file.append(lbl)
        current_file.append(eachFile)

        # Adding the current file's data to the dataframe
        data_set.loc[processed_files]=deepcopy(current_file)
        processed_files+=1
    return None

###################################### END #############################################################################   


################# Main Start #####################################
# Variables/Object-References are :
processed_files=0
section_number=0
total_api=0
column_names=[]

# Reading the list named "ALLFeatures.list" which was written by "RandomFeatureSelection.py"
# and saving the list to "column_names" list.
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/FrequentlyUsedAPI.list","rb") as read_file:
    frequently_used_api=pickle.load(read_file)
    read_file.close()
with open("C:/Users/Gamer/Documents/Implementation/UpdatedFeature/FrequentlyUsedASM.list","rb") as read_file:
    frequently_used_asm=pickle.load(read_file)
    read_file.close()

last_part_of_the_features=["SectionCharacteristics","FileCharacteristics","size","Entropy","label","Name"]
column_names+=frequently_used_api
column_names+=frequently_used_asm
column_names+=last_part_of_the_features



# Creating a dataframe "data_set" to store the extracted information of raw PE files
# This dataframe has as many columns as of "column_names"
data_set=pandas.DataFrame(columns=column_names)


# Location of the raw benign files
file_list=glob.glob("D:/softwares/exefiles/Benign_1/*.exe")
file_list+=glob.glob("D:/softwares/exefiles/Benign_2/*.exe")
file_list+=glob.glob("D:/softwares/exefiles/Benign_3/*.exe")
file_list+=glob.glob("D:/softwares/exefiles/Benign_4/*.exe")
file_list+=glob.glob("D:/softwares/exefiles/Benign_5/*.exe")
file_list+=glob.glob("D:/softwares/exefiles/important/*.exe")
file_list+=glob.glob("D:/softwares/exefiles/important2/*.exe")



# calling myfunc() to fetch info from benign files
lbl=0 # It denotes the label, 0 means Benign
myfunc()




# Location of the raw ransomware files
file_list.clear()
file_list+=glob.glob("G:/1/*")
file_list+=glob.glob("G:/2/*")
file_list+=glob.glob("G:/3/*")
file_list+=glob.glob("G:/filess/*")
file_list+=glob.glob("G:/test/*")
file_list+=glob.glob("G:/test1/*")
file_list+=glob.glob("H:/4/*")
file_list+=glob.glob("H:/5/*")
file_list+=glob.glob("H:/6/*")


# calling myfunc() to fetch info malicious files
lbl=1 # It denotes the label, 0 means ransomware
myfunc()




# writing the dataset to disk as "ALLdataset" and it is a dataframe object
with open("ALLdataset","wb") as my_dataset_file_handle:
    pickle.dump(data_set, my_dataset_file_handle)
    my_dataset_file_handle.close()
with open("EndFeature.list","wb") as write_to_disk:
    pickle.dump(last_part_of_the_features,write_to_disk)
    write_to_disk.close()
    

frequency = 1800
duration= 1000
winsound.Beep(frequency,duration)
#**************************************************