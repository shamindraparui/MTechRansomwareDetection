import pandas
import pefile
import glob
import pickle
from capstone import *
from copy import deepcopy
from pefile import PEFormatError



###############################################################################################
#      this script is used to predict the class of a given binary
#      
#      Date - 25-7-2020
#      version - 25-7-2020.v2
###############################################################################################







#==================== START of the Function ========================================
def is_valid_EP(my_file, ep, file_path):
    global  section_number
    global total_api
    section_number=-1
    total_api=0
    f=0
    
    for sec in my_file.sections:
        section_number+=1
        if sec.contains_rva(ep):
            f=1
            break
    if f==1:
        if my_file.sections[section_number].Name in [b".aspack\x00", b".adata\x00\x00", b".pec\x00\x00\x00\x00", b"UPX1\x00\x00\x00\x00",
                        b"UPX0\x00\x00\x00\x00",b".MaskPE\x00",b"RCryptor",b".UPX1\x00\x00\x00",
                        b".UPX0\x00\x00\x00", b".yP\x00\x00\x00\x00\x00"]:
            f=2
    try:
        for eachDLL in my_file.DIRECTORY_ENTRY_IMPORT:
            total_api+=len(eachDLL.imports)
    except Exception as e:
        f=(-99)
    return f
#==================== END ====================





#========= Function starts ======================
def myfunc():
    global processed_files
    global lbl
    global data_set
    global file_list
    global scale_value
    current_file=[]
    all_APIs=[]
    all_ASM=[]
    
    for eachFile in file_list:
        all_APIs.clear()
        all_ASM.clear()
        current_file.clear()
    
        # following try block tries to determine whether a file is valid or packed or corrupted.
        # if file is valid, then only proceed to fetch the info. otherwise continues with the next file from the list.
        try:
            pe=pefile.PE(eachFile)
            entryPoint=pe.OPTIONAL_HEADER.AddressOfEntryPoint
            check_valid=is_valid_EP(pe, entryPoint, eachFile)
            if total_api < 2:
                print(".net Framework file.\t", eachFile)
                continue
            elif check_valid == 2:
                print("Packed.\t", eachFile)
                continue
            elif total_api <= 20:
                print("Possibly Packed by a packer or .Net file.\t", eachFile)
                continue
            elif check_valid == 0:
                print("Invalid EP. \t", eachFile)
                continue
            elif check_valid == -99:
                print("No Import Directory.\t", eachFile)
                continue
        except Exception as p:
            print("Error with this ---> -\t", eachFile)
            continue
        
        
        
        # following try block tries to fetch all the imported API names from the given file. If the file does not contain any
        # API or malformed, then coninues with the next file from the list.
        try:
            for imported_dll in pe.DIRECTORY_ENTRY_IMPORT:   
                for func in imported_dll.imports:            
                    if func.name is not None:
                        all_APIs.append(func.name.decode('utf-8'))
            
            
            # Following loop checks the existence of APIs with the data_set features corresponding to APIs
            # If an API of the current file exists in the data_frame features, then entry "current_file" for this file will
            # contain 1. Otherwise 0. 
            iteration=0
            api_list_length=len(frequently_used_api)
            while iteration<api_list_length:
                if frequently_used_api[iteration] in all_APIs:
                    current_file.append(1)
                else:
                    current_file.append(0)
                iteration+=1
        except Exception as p:
            print("From API. ",p, eachFile)
            continue

        # Following try block reads the assembly. If any error occurs, continues with the
        # next file from the list.
        
        try:
            rawSize=pe.sections[section_number].SizeOfRawData
            data = pe.get_memory_mapped_image()[entryPoint:entryPoint+rawSize]
            md = Cs(CS_ARCH_X86, CS_MODE_32)
            for i in md.disasm(data, entryPoint):
                if i.mnemonic in frequently_used_asm:
                    all_ASM.append(i.mnemonic)

            # Following loop checks the existence of assembly instruction with the frequently used set
            iteration=0
            asm_list_length=len(frequently_used_asm)
            while iteration < asm_list_length:
                if frequently_used_asm[iteration] in all_ASM:
                    occured=all_ASM.count(frequently_used_asm[iteration])
                    size=(pe.sections[section_number].SizeOfRawData)
                    scaledFrequency=int((occured/size)*scale_value)
                    current_file.append(deepcopy(scaledFrequency))
                else:
                    current_file.append(0)
                iteration+=1

        except Exception as p:
            print("From ASM. ",p, eachFile)
            continue
        try:
            
            current_file.append(pe.FILE_HEADER.Characteristics)
            fileSize=pe.sections[section_number].SizeOfRawData
            
            pe.close()
        except Exception as p:
            print("From Section characteristics.\t", eachFile)
            continue

        
        data_set.loc[processed_files]=deepcopy(current_file)
        processed_files+=1
    return None

#============= END ====================




################# Main Start #####################################
# Variables/Object-References are :
processed_files=0
section_number=0
total_api=0
column_names=[]
scale_value=500*1048576

# name of the features
frequently_used_api=['CloseHandle', 'GetStdHandle', 'CryptExportPKCS8', 'GetModuleFileNameA', 'QueryPerformanceCounter', 'SetEndOfFile', 'GetModuleHandleA', 'Sleep', 'HeapAlloc', 'ExitProcess', 'VirtualFree', 'ReadFile', 'SetFilePointer', 'VirtualAlloc', 'UnhandledExceptionFilter', 'LeaveCriticalSection', 'GetCurrentThreadId', 'GetCurrentProcess', '__setusermatherr', 'GetProcAddress', 'GetProcessHeap', 'InitializeCriticalSection', 'CryptCATAdminReleaseContext', 'WriteFile', 'CryptEncrypt', 'CryptReleaseContext', 'WaitForSingleObject', 'GetSystemTimeAsFileTime', 'FreeLibrary']

frequently_used_asm=['test', 'push', 'mov', 'int3', 'je', 'pop', 'cmp', 'add', 'jmp', 'jne']

last_part_of_the_features=["FileCharacteristics"]
column_names+=frequently_used_api
column_names+=frequently_used_asm
column_names+=last_part_of_the_features


# this dataframe will contain the fetched information from the given binary
data_set=pandas.DataFrame(columns=column_names)


# Location of the raw file
file_list=glob.glob("D:/softwares/exefiles/software/atlantis3en.exe")
myfunc()

# loading the classifier from disk
with open("LGBM","rb") as file_handle:
    classifier=pickle.load(file_handle)
    file_handle.close()
predictThis=data_set
for e in predictThis.columns:
    column_type=predictThis[e].dtype
    if column_type=="object":
        predictThis[e]=data_set[e].astype("category")

pred=classifier.predict(predictThis)
print("Predicted class is - ", pred)